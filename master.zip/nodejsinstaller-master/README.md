# NodejsInstaller2018
Automated Shell Script To Install node js on any Linux 
Made By hackerstech
Download google verification bypasser 2018:https://github.com/hackerstech/nodejsinstaller.git

usage :
1)cd Desktop/
1
2)git clone https://github.com/hackerstech/nodejsinstaller.git

3)cd nodejsinstaller

4)chmod +x nodejs.sh 

5)./nodejs.sh
After running nodejs.sh

1) Installer of Nodejs
2) Quit
#? 


Thanks for Using you're script

